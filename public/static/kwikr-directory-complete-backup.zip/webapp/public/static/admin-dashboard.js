// Admin Dashboard JavaScript

let currentUser = null

// Fallback API request function if app.js is not loaded
if (typeof window.apiRequest === 'undefined') {
  window.apiRequest = async function(endpoint, options = {}) {
    // Try to get token from localStorage first, then from cookies
    let token = null
    try {
      token = localStorage.getItem('sessionToken')
    } catch (e) {
      // localStorage access denied, try to get from cookies
      const cookies = document.cookie.split(';')
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=')
        if (name === 'session') {
          token = value
          break
        }
      }
    }
    
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` })
      },
      ...options
    }
    
    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body)
    }
    
    try {
      const response = await fetch(`/api${endpoint}`, config)
      const data = await response.json()
      
      if (!response.ok) {
        throw new Error(data.error || 'Request failed')
      }
      
      return data
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }
}

// Utility functions
if (typeof window.formatCurrency === 'undefined') {
  window.formatCurrency = function(amount) {
    return new Intl.NumberFormat('en-CA', {
      style: 'currency',
      currency: 'CAD'
    }).format(amount)
  }
}

if (typeof window.formatDate === 'undefined') {
  window.formatDate = function(dateString) {
    return new Date(dateString).toLocaleDateString('en-CA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }
}

if (typeof window.getStatusBadge === 'undefined') {
  window.getStatusBadge = function(status) {
    const statusClasses = {
      'posted': 'bg-blue-100 text-blue-800',
      'assigned': 'bg-yellow-100 text-yellow-800',
      'in_progress': 'bg-purple-100 text-purple-800',
      'completed': 'bg-green-100 text-green-800',
      'cancelled': 'bg-red-100 text-red-800'
    }
    
    const statusLabels = {
      'posted': 'Posted',
      'assigned': 'Assigned',
      'in_progress': 'In Progress',
      'completed': 'Completed',
      'cancelled': 'Cancelled'
    }
    
    const cssClass = statusClasses[status] || 'bg-gray-100 text-gray-800'
    const label = statusLabels[status] || status
    
    return `<span class="px-2 py-1 rounded-full text-xs font-medium ${cssClass}">${label}</span>`
  }
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
  console.log('Admin dashboard initializing...')
  
  // For demo purposes, use embedded user data if available
  if (typeof window.currentUser !== 'undefined') {
    currentUser = window.currentUser
    console.log('Current user loaded:', currentUser)
  }
  
  // Load demo data with error handling
  try {
    loadPlatformStatsDemo()
  } catch (error) {
    console.error('Failed to load platform stats:', error)
  }
  
  try {
    loadRecentJobsDemo()
  } catch (error) {
    console.error('Failed to load recent jobs:', error)
  }
  
  console.log('Admin dashboard initialized')
})

// Load user information
async function loadUserInfo() {
  try {
    const response = await apiRequest('/auth/me')
    currentUser = response.user
    
    if (currentUser.role !== 'admin') {
      window.location.href = '/dashboard'
      return
    }
  } catch (error) {
    console.error('Failed to load user info:', error)
    window.location.href = '/?session=expired'
  }
}

// Load platform statistics with demo data
function loadPlatformStatsDemo() {
  console.log('Loading platform stats demo...')
  
  // Demo statistics
  const demoStats = {
    totalUsers: 2847,
    totalJobs: 1356,
    pendingCompliance: 12,
    activeDisputes: 3
  }
  
  // Simulate loading delay then update stats
  setTimeout(() => {
    try {
      // Animate counter updates
      animateCounter('totalUsers', demoStats.totalUsers)
      animateCounter('totalJobs', demoStats.totalJobs)
      animateCounter('pendingCompliance', demoStats.pendingCompliance)
      animateCounter('activeDisputes', demoStats.activeDisputes)
      console.log('Platform stats loaded successfully')
    } catch (error) {
      console.error('Error updating platform stats:', error)
      // Fallback to direct updates
      document.getElementById('totalUsers').textContent = demoStats.totalUsers.toLocaleString()
      document.getElementById('totalJobs').textContent = demoStats.totalJobs.toLocaleString()
      document.getElementById('pendingCompliance').textContent = demoStats.pendingCompliance
      document.getElementById('activeDisputes').textContent = demoStats.activeDisputes
    }
  }, 500)
}

// Animate counter from 0 to target value
function animateCounter(elementId, targetValue) {
  const element = document.getElementById(elementId)
  const duration = 1500 // 1.5 seconds
  const steps = 30
  const increment = targetValue / steps
  let current = 0
  
  const timer = setInterval(() => {
    current += increment
    if (current >= targetValue) {
      element.textContent = targetValue.toLocaleString()
      clearInterval(timer)
    } else {
      element.textContent = Math.floor(current).toLocaleString()
    }
  }, duration / steps)
}

// Load recent jobs with demo data
function loadRecentJobsDemo() {
  console.log('Loading recent jobs demo...')
  
  // Demo jobs data
  const demoJobs = [
    {
      id: 1,
      title: "Kitchen Deep Cleaning",
      category: "Cleaning Services", 
      status: "in_progress",
      budget_min: 120,
      budget_max: 180,
      created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
      client_name: "Jennifer L."
    },
    {
      id: 2,
      title: "Bathroom Renovation",
      category: "Handyman Services",
      status: "assigned", 
      budget_min: 800,
      budget_max: 1200,
      created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days ago
      client_name: "Mike R."
    },
    {
      id: 3,
      title: "Plumbing Repair", 
      category: "Plumbing",
      status: "completed",
      budget_min: 200,
      budget_max: 300,
      created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week ago
      client_name: "Sarah M."
    },
    {
      id: 4,
      title: "Electrical Outlet Installation",
      category: "Electrical Work", 
      status: "posted",
      budget_min: 150,
      budget_max: 250,
      created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      client_name: "David K."
    },
    {
      id: 5,
      title: "Garden Landscaping",
      category: "Landscaping",
      status: "assigned",
      budget_min: 500,
      budget_max: 800,
      created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
      client_name: "Emma T."
    }
  ]
  
  // Simulate loading delay then render jobs
  setTimeout(() => {
    try {
      renderRecentJobs(demoJobs)
      console.log('Recent jobs loaded successfully')
    } catch (error) {
      console.error('Error rendering recent jobs:', error)
      // Fallback error display
      const container = document.getElementById('recentJobs')
      if (container) {
        container.innerHTML = `
          <div class="text-center text-red-500 py-4">
            <i class="fas fa-exclamation-triangle mb-2"></i>
            <p class="text-sm">Error loading jobs</p>
          </div>
        `
      }
    }
  }, 800)
}

// Render recent jobs
function renderRecentJobs(jobs) {
  const container = document.getElementById('recentJobs')
  
  if (!jobs || jobs.length === 0) {
    container.innerHTML = `
      <div class="text-center text-gray-500 py-4">
        <i class="fas fa-briefcase text-gray-300 text-2xl mb-2"></i>
        <p class="text-sm">No recent jobs</p>
      </div>
    `
    return
  }
  
  const jobsHtml = jobs.slice(0, 5).map(job => `
    <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
      <div class="flex-1">
        <h4 class="text-sm font-medium text-gray-900">${job.title}</h4>
        <p class="text-xs text-gray-600">${job.category_name || job.category}</p>
        <p class="text-xs text-gray-500">${formatDate(job.created_at)}</p>
      </div>
      <div class="text-right">
        ${getStatusBadge(job.status)}
        <div class="text-xs text-gray-600 mt-1">
          ${formatCurrency(job.budget_min)} - ${formatCurrency(job.budget_max)}
        </div>
      </div>
    </div>
  `).join('')
  
  container.innerHTML = jobsHtml
}

// Tab management
function showTab(tabName) {
  // Hide all tab contents
  const tabContents = document.querySelectorAll('.tab-content')
  tabContents.forEach(tab => tab.classList.add('hidden'))
  
  // Remove active class from all tabs
  const tabs = document.querySelectorAll('.admin-tab')
  tabs.forEach(tab => {
    tab.classList.remove('border-kwikr-green', 'text-kwikr-green')
    tab.classList.add('border-transparent', 'text-gray-500')
  })
  
  // Show selected tab content
  document.getElementById(tabName + 'Tab').classList.remove('hidden')
  
  // Add active class to selected tab
  const activeTab = event.target
  activeTab.classList.remove('border-transparent', 'text-gray-500')
  activeTab.classList.add('border-kwikr-green', 'text-kwikr-green')
  
  // Load tab-specific data
  switch(tabName) {
    case 'users':
      loadUsers()
      break
    case 'compliance':
      loadCompliance()
      break
    case 'disputes':
      loadDisputes()
      break
    case 'analytics':
      loadAnalytics()
      break
  }
}

// Load users with demo data
async function loadUsers() {
  const container = document.getElementById('usersList')
  container.innerHTML = `
    <div class="text-center text-gray-500 py-8">
      <i class="fas fa-spinner fa-spin text-2xl mb-4"></i>
      <p>Loading users...</p>
    </div>
  `
  
  // Simulate loading delay
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  const roleFilter = document.getElementById('userRoleFilter').value
  
  // Demo users data
  const allDemoUsers = [
    {
      id: 1,
      first_name: "Jennifer",
      last_name: "Lopez",
      email: "jennifer.l@email.com",
      role: "client", 
      city: "Toronto",
      province: "ON",
      is_verified: true,
      is_active: true,
      created_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days ago
    },
    {
      id: 2,
      first_name: "Mike",
      last_name: "Roberts", 
      email: "mike.r@email.com",
      role: "client",
      city: "Vancouver",
      province: "BC", 
      is_verified: true,
      is_active: true,
      created_at: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString() // 45 days ago
    },
    {
      id: 3,
      first_name: "Sarah",
      last_name: "Mitchell",
      email: "sarah.m@cleanpro.ca",
      role: "worker",
      city: "Calgary", 
      province: "AB",
      is_verified: true,
      is_active: true,
      created_at: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString() // 60 days ago
    },
    {
      id: 4,
      first_name: "David",
      last_name: "Kim",
      email: "david.k@email.com",
      role: "client",
      city: "Montreal",
      province: "QC",
      is_verified: false,
      is_active: true,
      created_at: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString() // 15 days ago
    },
    {
      id: 5,
      first_name: "Emma",
      last_name: "Thompson",
      email: "emma.t@email.com", 
      role: "client",
      city: "Ottawa",
      province: "ON",
      is_verified: true,
      is_active: false,
      created_at: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString() // 90 days ago
    },
    {
      id: 6,
      first_name: "James",
      last_name: "Wilson",
      email: "james.w@fixitpro.ca",
      role: "worker", 
      city: "Edmonton",
      province: "AB",
      is_verified: true,
      is_active: true,
      created_at: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000).toISOString() // 120 days ago
    }
  ]
  
  // Filter users based on role selection
  const filteredUsers = roleFilter ? allDemoUsers.filter(user => user.role === roleFilter) : allDemoUsers
  
  renderUsers(filteredUsers)
}

// Render users
function renderUsers(users) {
  const container = document.getElementById('usersList')
  
  if (!users || users.length === 0) {
    container.innerHTML = `
      <div class="text-center text-gray-500 py-8">
        <i class="fas fa-users text-gray-300 text-4xl mb-4"></i>
        <p>No users found</p>
      </div>
    `
    return
  }
  
  const usersHtml = users.map(user => `
    <div class="flex justify-between items-center p-4 border border-gray-200 rounded-lg mb-3">
      <div class="flex-1">
        <h4 class="text-sm font-medium text-gray-900">${user.first_name} ${user.last_name}</h4>
        <p class="text-sm text-gray-600">${user.email}</p>
        <div class="flex items-center space-x-4 mt-1">
          <span class="text-xs text-gray-500">${user.role}</span>
          <span class="text-xs text-gray-500">${user.city}, ${user.province}</span>
          <span class="text-xs text-gray-500">Joined ${formatDate(user.created_at)}</span>
        </div>
      </div>
      <div class="text-right">
        <div class="flex items-center space-x-2 mb-2">
          ${user.is_verified ? 
            '<span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Verified</span>' : 
            '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pending</span>'
          }
          ${user.is_active ? 
            '<span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Active</span>' : 
            '<span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Inactive</span>'
          }
        </div>
        <div class="flex space-x-2">
          <button onclick="viewUserProfile(${user.id})" class="text-kwikr-green hover:text-green-600 text-xs">
            View
          </button>
          <button onclick="toggleUserStatus(${user.id}, ${user.is_active})" class="text-blue-600 hover:text-blue-700 text-xs">
            ${user.is_active ? 'Suspend' : 'Activate'}
          </button>
        </div>
      </div>
    </div>
  `).join('')
  
  container.innerHTML = usersHtml
}

// Load compliance reviews with demo data
async function loadCompliance() {
  const container = document.getElementById('complianceList')
  container.innerHTML = `
    <div class="text-center text-gray-500 py-8">
      <i class="fas fa-spinner fa-spin text-2xl mb-4"></i>
      <p>Loading compliance reviews...</p>
    </div>
  `
  
  // Simulate loading delay
  await new Promise(resolve => setTimeout(resolve, 800))
  
  // Demo compliance data
  const demoCompliance = [
    {
      id: 1,
      worker_name: "Sarah Mitchell",
      worker_email: "sarah.m@cleanpro.ca",
      type: "Insurance Verification", 
      status: "pending",
      submitted_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      priority: "high"
    },
    {
      id: 2,
      worker_name: "James Wilson", 
      worker_email: "james.w@fixitpro.ca",
      type: "Background Check",
      status: "approved",
      submitted_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      priority: "medium"
    },
    {
      id: 3,
      worker_name: "Alex Chen",
      worker_email: "alex.c@proservices.ca", 
      type: "License Verification",
      status: "rejected",
      submitted_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      priority: "high"
    }
  ]
  
  renderCompliance(demoCompliance)
}

// Render compliance reviews
function renderCompliance(compliance) {
  const container = document.getElementById('complianceList')
  
  if (!compliance || compliance.length === 0) {
    container.innerHTML = `
      <div class="text-center text-gray-500 py-8">
        <i class="fas fa-certificate text-gray-300 text-4xl mb-4"></i>
        <p>No pending compliance reviews</p>
      </div>
    `
    return
  }
  
  const complianceHtml = compliance.map(item => `
    <div class="flex justify-between items-center p-4 border border-gray-200 rounded-lg mb-3">
      <div class="flex-1">
        <h4 class="text-sm font-medium text-gray-900">${item.worker_name}</h4>
        <p class="text-sm text-gray-600">${item.worker_email}</p>
        <p class="text-sm text-gray-500">${item.type} • ${formatDate(item.submitted_at)}</p>
      </div>
      <div class="text-right">
        <div class="flex items-center space-x-2 mb-2">
          ${item.status === 'pending' ? 
            '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Pending Review</span>' :
            item.status === 'approved' ?
            '<span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Approved</span>' :
            '<span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Rejected</span>'
          }
          ${item.priority === 'high' ? 
            '<span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High Priority</span>' :
            '<span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Normal</span>'
          }
        </div>
        <div class="flex space-x-2">
          <button onclick="reviewCompliance(${item.id}, 'approve')" class="text-green-600 hover:text-green-700 text-xs">
            Approve
          </button>
          <button onclick="reviewCompliance(${item.id}, 'reject')" class="text-red-600 hover:text-red-700 text-xs">
            Reject
          </button>
          <button onclick="viewComplianceDetails(${item.id})" class="text-kwikr-green hover:text-green-600 text-xs">
            Details
          </button>
        </div>
      </div>
    </div>
  `).join('')
  
  container.innerHTML = complianceHtml
}

// Load disputes with demo data
async function loadDisputes() {
  const container = document.getElementById('disputesList')
  container.innerHTML = `
    <div class="text-center text-gray-500 py-8">
      <i class="fas fa-spinner fa-spin text-2xl mb-4"></i>
      <p>Loading disputes...</p>
    </div>
  `
  
  // Simulate loading delay
  await new Promise(resolve => setTimeout(resolve, 600))
  
  // Demo disputes data
  const demoDisputes = [
    {
      id: 1,
      job_title: "Kitchen Cleaning Service",
      client_name: "Jennifer Lopez",
      worker_name: "Sarah Mitchell", 
      issue: "Work quality dispute",
      status: "open",
      priority: "high",
      created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      amount: 150
    },
    {
      id: 2,
      job_title: "Bathroom Renovation", 
      client_name: "Mike Roberts",
      worker_name: "James Wilson",
      issue: "Payment delay",
      status: "investigating",
      priority: "medium", 
      created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      amount: 800
    },
    {
      id: 3,
      job_title: "Electrical Outlet Installation",
      client_name: "David Kim",
      worker_name: "Alex Chen",
      issue: "Scope disagreement", 
      status: "resolved",
      priority: "low",
      created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
      amount: 200
    }
  ]
  
  renderDisputes(demoDisputes)
}

// Render disputes
function renderDisputes(disputes) {
  const container = document.getElementById('disputesList')
  
  if (!disputes || disputes.length === 0) {
    container.innerHTML = `
      <div class="text-center text-gray-500 py-8">
        <i class="fas fa-gavel text-gray-300 text-4xl mb-4"></i>
        <p>No active disputes</p>
      </div>
    `
    return
  }
  
  const disputesHtml = disputes.map(dispute => `
    <div class="flex justify-between items-center p-4 border border-gray-200 rounded-lg mb-3">
      <div class="flex-1">
        <h4 class="text-sm font-medium text-gray-900">${dispute.job_title}</h4>
        <p class="text-sm text-gray-600">${dispute.client_name} vs ${dispute.worker_name}</p>
        <p class="text-sm text-gray-500">${dispute.issue} • ${formatDate(dispute.created_at)}</p>
        <p class="text-sm font-medium text-gray-700 mt-1">${formatCurrency(dispute.amount)}</p>
      </div>
      <div class="text-right">
        <div class="flex items-center space-x-2 mb-2">
          ${dispute.status === 'open' ? 
            '<span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Open</span>' :
            dispute.status === 'investigating' ?
            '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Investigating</span>' :
            '<span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Resolved</span>'
          }
          ${dispute.priority === 'high' ? 
            '<span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">High</span>' :
            dispute.priority === 'medium' ?
            '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs">Medium</span>' :
            '<span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">Low</span>'
          }
        </div>
        <div class="flex space-x-2">
          <button onclick="viewDisputeDetails(${dispute.id})" class="text-kwikr-green hover:text-green-600 text-xs">
            View
          </button>
          <button onclick="mediateDispute(${dispute.id})" class="text-blue-600 hover:text-blue-700 text-xs">
            Mediate
          </button>
          ${dispute.status !== 'resolved' ? 
            '<button onclick="resolveDispute(' + dispute.id + ')" class="text-green-600 hover:text-green-700 text-xs">Resolve</button>' :
            ''
          }
        </div>
      </div>
    </div>
  `).join('')
  
  container.innerHTML = disputesHtml
}

// Load analytics
function loadAnalytics() {
  const container = document.getElementById('platformStats')
  container.innerHTML = `
    <div class="text-center text-gray-500">
      <i class="fas fa-chart-bar text-gray-300 text-4xl mb-4"></i>
      <p>Advanced analytics coming soon!</p>
    </div>
  `
}

// User management functions
function viewUserProfile(userId) {
  showNotification(`User profile #${userId} feature coming soon!`, 'info')
}

function toggleUserStatus(userId, currentStatus) {
  const action = currentStatus ? 'suspend' : 'activate'
  showNotification(`User ${action} feature coming soon!`, 'info')
}

// Export functions
function exportJobs() {
  showNotification('Job export feature coming soon!', 'info')
}

function exportUsers() {
  showNotification('User export feature coming soon!', 'info')
}

// Compliance management functions
function reviewCompliance(complianceId, action) {
  showNotification(`Compliance review ${complianceId} ${action}d!`, 'success')
  // Reload compliance data to show updated status
  setTimeout(() => {
    loadCompliance()
  }, 1000)
}

function viewComplianceDetails(complianceId) {
  showNotification(`Viewing compliance details #${complianceId}`, 'info')
}

// Dispute management functions  
function viewDisputeDetails(disputeId) {
  showNotification(`Viewing dispute details #${disputeId}`, 'info')
}

function mediateDispute(disputeId) {
  showNotification(`Starting mediation for dispute #${disputeId}`, 'info')
}

function resolveDispute(disputeId) {
  showNotification(`Dispute #${disputeId} marked as resolved!`, 'success')
  // Reload disputes data to show updated status
  setTimeout(() => {
    loadDisputes()
  }, 1000)
}

// Notification function
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div')
  notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full ${
    type === 'success' ? 'bg-green-500 text-white' : 
    type === 'error' ? 'bg-red-500 text-white' :
    'bg-blue-500 text-white'
  }`
  
  notification.innerHTML = `
    <div class="flex items-center">
      <i class="fas ${
        type === 'success' ? 'fa-check-circle' : 
        type === 'error' ? 'fa-exclamation-circle' :
        'fa-info-circle'
      } mr-2"></i>
      <span>${message}</span>
    </div>
  `
  
  document.body.appendChild(notification)
  
  // Animate in
  setTimeout(() => {
    notification.classList.remove('translate-x-full')
  }, 100)
  
  // Auto remove after 3 seconds
  setTimeout(() => {
    notification.classList.add('translate-x-full')
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification)
      }
    }, 300)
  }, 3000)
}

// Make functions globally available
window.showTab = showTab
window.loadUsers = loadUsers
window.loadCompliance = loadCompliance
window.loadDisputes = loadDisputes
window.viewUserProfile = viewUserProfile
window.toggleUserStatus = toggleUserStatus
window.reviewCompliance = reviewCompliance
window.viewComplianceDetails = viewComplianceDetails
window.viewDisputeDetails = viewDisputeDetails
window.mediateDispute = mediateDispute
window.resolveDispute = resolveDispute
window.exportJobs = exportJobs
window.exportUsers = exportUsers
window.showNotification = showNotification