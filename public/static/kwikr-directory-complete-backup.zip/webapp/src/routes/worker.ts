import { Hono } from 'hono'

type Bindings = {
  DB: D1Database;
}

// File upload utility function
const processFileUpload = async (file: File, maxSize: number = 5 * 1024 * 1024, allowedTypes: string[] = ['image/jpeg', 'image/png', 'application/pdf']) => {
  // Validate file type
  if (!allowedTypes.includes(file.type)) {
    throw new Error(`File type not allowed. Allowed types: ${allowedTypes.join(', ')}`)
  }
  
  // Check file size
  if (file.size > maxSize) {
    const maxSizeMB = Math.round(maxSize / (1024 * 1024))
    throw new Error(`File size must be less than ${maxSizeMB}MB`)
  }
  
  // Convert file to base64 for storage
  const fileBuffer = await file.arrayBuffer()
  const fileBase64 = btoa(String.fromCharCode(...new Uint8Array(fileBuffer)))
  const fileUrl = `data:${file.type};base64,${fileBase64}`
  
  return {
    fileName: file.name,
    fileSize: file.size,
    fileType: file.type,
    fileUrl: fileUrl,
    fileBase64: fileBase64
  }
}

export const workerRoutes = new Hono<{ Bindings: Bindings }>()

// Middleware to verify worker authentication
const requireWorkerAuth = async (c: any, next: any) => {
  // Try to get session token from multiple sources:
  // 1. Authorization header (for API requests)
  // 2. Cookie (for dashboard pages)
  let sessionToken = null
  
  // Check Authorization header first
  const authHeader = c.req.header('Authorization')
  if (authHeader && authHeader.startsWith('Bearer ')) {
    sessionToken = authHeader.replace('Bearer ', '')
  }
  
  // If no Authorization header, try cookies
  if (!sessionToken) {
    const cookies = c.req.header('Cookie')
    if (cookies) {
      const match = cookies.match(/session=([^;]+)/)
      if (match) {
        sessionToken = match[1]
      }
    }
  }
  
  if (!sessionToken) {
    return c.json({ error: 'Authentication required', expired: true }, 401)
  }
  
  try {
    const session = await c.env.DB.prepare(`
      SELECT s.user_id, u.role, u.first_name, u.last_name, u.email, u.is_verified
      FROM user_sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.session_token = ? AND s.expires_at > CURRENT_TIMESTAMP AND u.is_active = 1 AND u.role = 'worker'
    `).bind(sessionToken).first()
    
    if (!session) {
      return c.json({ error: 'Invalid session or not a worker' }, 401)
    }
    
    c.set('user', session)
    await next()
  } catch (error) {
    console.error('Worker auth middleware error:', error)
    return c.json({ error: 'Authentication failed' }, 500)
  }
}

// ===== COMPLIANCE MANAGEMENT =====

// Get worker compliance information
workerRoutes.get('/compliance', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const compliance = await c.env.DB.prepare(`
      SELECT * FROM worker_compliance WHERE user_id = ?
    `).bind(user.user_id).first()
    
    return c.json({ 
      compliance: compliance || {
        user_id: user.user_id,
        wsib_number: null,
        wsib_valid_until: null,
        insurance_provider: null,
        insurance_policy_number: null,
        insurance_valid_until: null,
        license_type: null,
        license_number: null,
        license_valid_until: null,
        compliance_status: 'pending'
      }
    })
  } catch (error) {
    console.error('Get compliance error:', error)
    return c.json({ error: 'Failed to get compliance information' }, 500)
  }
})

// Update worker compliance information
workerRoutes.put('/compliance', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const {
      wsib_number,
      wsib_valid_until,
      insurance_provider,
      insurance_policy_number,
      insurance_valid_until,
      license_type,
      license_number,
      license_valid_until
    } = await c.req.json()

    // Check if compliance record exists
    const existing = await c.env.DB.prepare(`
      SELECT id FROM worker_compliance WHERE user_id = ?
    `).bind(user.user_id).first()

    if (existing) {
      // Update existing record
      await c.env.DB.prepare(`
        UPDATE worker_compliance SET
          wsib_number = ?, wsib_valid_until = ?,
          insurance_provider = ?, insurance_policy_number = ?, insurance_valid_until = ?,
          license_type = ?, license_number = ?, license_valid_until = ?,
          documents_uploaded = 1,
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ?
      `).bind(
        wsib_number, wsib_valid_until,
        insurance_provider, insurance_policy_number, insurance_valid_until,
        license_type, license_number, license_valid_until,
        user.user_id
      ).run()
    } else {
      // Insert new record
      await c.env.DB.prepare(`
        INSERT INTO worker_compliance (
          user_id, wsib_number, wsib_valid_until,
          insurance_provider, insurance_policy_number, insurance_valid_until,
          license_type, license_number, license_valid_until,
          compliance_status, documents_uploaded
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 1)
      `).bind(
        user.user_id, wsib_number, wsib_valid_until,
        insurance_provider, insurance_policy_number, insurance_valid_until,
        license_type, license_number, license_valid_until
      ).run()
    }

    return c.json({ success: true, message: 'Compliance information updated successfully' })
  } catch (error) {
    console.error('Update compliance error:', error)
    return c.json({ error: 'Failed to update compliance information' }, 500)
  }
})

// ===== SERVICES MANAGEMENT =====

// Get worker services
workerRoutes.get('/services', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const services = await c.env.DB.prepare(`
      SELECT ws.*, jc.name as category_name, jc.icon_class
      FROM worker_services ws
      LEFT JOIN job_categories jc ON ws.service_category = jc.name
      WHERE ws.user_id = ?
      ORDER BY ws.created_at DESC
    `).bind(user.user_id).all()
    
    return c.json({ services: services.results || [] })
  } catch (error) {
    console.error('Get services error:', error)
    return c.json({ error: 'Failed to get services' }, 500)
  }
})

// Add new service
workerRoutes.post('/services', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const {
      service_category,
      service_name,
      description,
      hourly_rate,
      service_area,
      years_experience,
      tags
    } = await c.req.json()

    const result = await c.env.DB.prepare(`
      INSERT INTO worker_services (
        user_id, service_category, service_name, description,
        hourly_rate, service_area, years_experience, is_available
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `).bind(
      user.user_id, service_category, service_name, description,
      hourly_rate, JSON.stringify(service_area || []), years_experience
    ).run()

    return c.json({ 
      success: true, 
      message: 'Service added successfully',
      service_id: result.meta.last_row_id
    })
  } catch (error) {
    console.error('Add service error:', error)
    return c.json({ error: 'Failed to add service' }, 500)
  }
})

// Update service
workerRoutes.put('/services/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const serviceId = c.req.param('id')
    const {
      service_category,
      service_name,
      description,
      hourly_rate,
      service_area,
      years_experience,
      is_available
    } = await c.req.json()

    await c.env.DB.prepare(`
      UPDATE worker_services SET
        service_category = ?, service_name = ?, description = ?,
        hourly_rate = ?, service_area = ?, years_experience = ?, is_available = ?
      WHERE id = ? AND user_id = ?
    `).bind(
      service_category, service_name, description,
      hourly_rate, JSON.stringify(service_area || []), years_experience, is_available ? 1 : 0,
      serviceId, user.user_id
    ).run()

    return c.json({ success: true, message: 'Service updated successfully' })
  } catch (error) {
    console.error('Update service error:', error)
    return c.json({ error: 'Failed to update service' }, 500)
  }
})

// Delete service
workerRoutes.delete('/services/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const serviceId = c.req.param('id')

    await c.env.DB.prepare(`
      DELETE FROM worker_services WHERE id = ? AND user_id = ?
    `).bind(serviceId, user.user_id).run()

    return c.json({ success: true, message: 'Service deleted successfully' })
  } catch (error) {
    console.error('Delete service error:', error)
    return c.json({ error: 'Failed to delete service' }, 500)
  }
})

// ===== BIDS MANAGEMENT =====

// Get worker bids history
workerRoutes.get('/bids', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const bids = await c.env.DB.prepare(`
      SELECT b.*, j.title as job_title, j.description as job_description,
             j.budget_min, j.budget_max, j.status as job_status, j.location_city, j.location_province,
             c.name as category_name, c.icon_class,
             u.first_name as client_first_name, u.last_name as client_last_name
      FROM bids b
      JOIN jobs j ON b.job_id = j.id
      JOIN job_categories c ON j.category_id = c.id
      JOIN users u ON j.client_id = u.id
      WHERE b.worker_id = ?
      ORDER BY b.submitted_at DESC
    `).bind(user.user_id).all()
    
    return c.json({ bids: bids.results || [] })
  } catch (error) {
    console.error('Get bids error:', error)
    return c.json({ error: 'Failed to get bids' }, 500)
  }
})

// Check if worker has already bid on a job
workerRoutes.get('/bids/check/:jobId', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const jobId = c.req.param('jobId')

    const existingBid = await c.env.DB.prepare(`
      SELECT b.*, 
             (SELECT COUNT(*) FROM bid_history WHERE bid_id = b.id) as modification_count
      FROM bids b
      WHERE b.job_id = ? AND b.worker_id = ? AND b.status != 'withdrawn'
    `).bind(jobId, user.user_id).first()

    return c.json({ 
      hasBid: !!existingBid, 
      bid: existingBid || null 
    })
  } catch (error) {
    console.error('Check bid error:', error)
    return c.json({ error: 'Failed to check bid status' }, 500)
  }
})

// Update/modify existing bid
workerRoutes.put('/bids/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const bidId = c.req.param('id')
    const { bid_amount, cover_message, estimated_timeline, modification_reason } = await c.req.json()

    // Get existing bid to save to history
    const existingBid = await c.env.DB.prepare(`
      SELECT * FROM bids WHERE id = ? AND worker_id = ? AND status = 'pending'
    `).bind(bidId, user.user_id).first()

    if (!existingBid) {
      return c.json({ error: 'Bid not found or cannot be modified' }, 404)
    }

    // Save current bid to history
    await c.env.DB.prepare(`
      INSERT INTO bid_history (bid_id, bid_amount, cover_message, estimated_timeline, modification_reason)
      VALUES (?, ?, ?, ?, ?)
    `).bind(bidId, existingBid.bid_amount, existingBid.cover_message, existingBid.estimated_timeline, modification_reason || 'Bid updated').run()

    // Update the bid
    await c.env.DB.prepare(`
      UPDATE bids SET 
        bid_amount = ?, 
        cover_message = ?, 
        estimated_timeline = ?,
        is_modified = 1,
        modification_count = modification_count + 1,
        last_modified_at = CURRENT_TIMESTAMP
      WHERE id = ? AND worker_id = ?
    `).bind(bid_amount, cover_message, estimated_timeline, bidId, user.user_id).run()

    return c.json({ success: true, message: 'Bid updated successfully' })
  } catch (error) {
    console.error('Update bid error:', error)
    return c.json({ error: 'Failed to update bid' }, 500)
  }
})

// Get bid history for a specific bid
workerRoutes.get('/bids/:id/history', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const bidId = c.req.param('id')

    // Verify bid belongs to worker
    const bid = await c.env.DB.prepare(`
      SELECT id FROM bids WHERE id = ? AND worker_id = ?
    `).bind(bidId, user.user_id).first()

    if (!bid) {
      return c.json({ error: 'Bid not found' }, 404)
    }

    const history = await c.env.DB.prepare(`
      SELECT * FROM bid_history WHERE bid_id = ? ORDER BY modified_at DESC
    `).bind(bidId).all()

    return c.json({ history: history.results || [] })
  } catch (error) {
    console.error('Get bid history error:', error)
    return c.json({ error: 'Failed to get bid history' }, 500)
  }
})

// Withdraw bid
workerRoutes.put('/bids/:id/withdraw', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const bidId = c.req.param('id')

    await c.env.DB.prepare(`
      UPDATE bids SET status = 'withdrawn' WHERE id = ? AND worker_id = ? AND status = 'pending'
    `).bind(bidId, user.user_id).run()

    return c.json({ success: true, message: 'Bid withdrawn successfully' })
  } catch (error) {
    console.error('Withdraw bid error:', error)
    return c.json({ error: 'Failed to withdraw bid' }, 500)
  }
})

// ===== COMPLIANCE DOCUMENTS =====

// Get compliance documents
workerRoutes.get('/compliance/documents', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    // Get compliance record
    const compliance = await c.env.DB.prepare(`
      SELECT id FROM worker_compliance WHERE user_id = ?
    `).bind(user.user_id).first()

    if (!compliance) {
      return c.json({ documents: [] })
    }

    const documents = await c.env.DB.prepare(`
      SELECT * FROM compliance_documents WHERE compliance_id = ? ORDER BY uploaded_at DESC
    `).bind(compliance.id).all()

    return c.json({ documents: documents.results || [] })
  } catch (error) {
    console.error('Get compliance documents error:', error)
    return c.json({ error: 'Failed to get compliance documents' }, 500)
  }
})

// Add compliance document (placeholder for file upload)
workerRoutes.post('/compliance/documents', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const { document_type, document_name, document_url, file_size } = await c.req.json()

    // Get or create compliance record
    let compliance = await c.env.DB.prepare(`
      SELECT id FROM worker_compliance WHERE user_id = ?
    `).bind(user.user_id).first()

    if (!compliance) {
      const result = await c.env.DB.prepare(`
        INSERT INTO worker_compliance (user_id, compliance_status) VALUES (?, 'pending')
      `).bind(user.user_id).run()
      compliance = { id: result.meta.last_row_id }
    }

    // Add document record
    await c.env.DB.prepare(`
      INSERT INTO compliance_documents (compliance_id, document_type, document_name, document_url, file_size)
      VALUES (?, ?, ?, ?, ?)
    `).bind(compliance.id, document_type, document_name, document_url, file_size || 0).run()

    return c.json({ success: true, message: 'Document added successfully' })
  } catch (error) {
    console.error('Add compliance document error:', error)
    return c.json({ error: 'Failed to add compliance document' }, 500)
  }
})

// Delete compliance document
workerRoutes.delete('/compliance/documents/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const documentId = c.req.param('id')

    // Verify document belongs to user
    const document = await c.env.DB.prepare(`
      SELECT cd.id FROM compliance_documents cd
      JOIN worker_compliance wc ON cd.compliance_id = wc.id
      WHERE cd.id = ? AND wc.user_id = ?
    `).bind(documentId, user.user_id).first()

    if (!document) {
      return c.json({ error: 'Document not found' }, 404)
    }

    await c.env.DB.prepare(`
      DELETE FROM compliance_documents WHERE id = ?
    `).bind(documentId).run()

    return c.json({ success: true, message: 'Document deleted successfully' })
  } catch (error) {
    console.error('Delete compliance document error:', error)
    return c.json({ error: 'Failed to delete compliance document' }, 500)
  }
})

// ===== PROFILE MANAGEMENT =====

// Get worker profile with extended information
workerRoutes.get('/profile', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const profile = await c.env.DB.prepare(`
      SELECT u.*, p.bio, p.profile_image_url, p.address_line1, p.address_line2, p.postal_code,
             p.date_of_birth, p.emergency_contact_name, p.emergency_contact_phone
      FROM users u
      LEFT JOIN user_profiles p ON u.id = p.user_id
      WHERE u.id = ?
    `).bind(user.user_id).first()
    
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404)
    }

    return c.json({ profile })
  } catch (error) {
    console.error('Get profile error:', error)
    return c.json({ error: 'Failed to get profile' }, 500)
  }
})

// Update worker profile
workerRoutes.put('/profile', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const data = await c.req.json()
    const {
      first_name = '',
      last_name = '',
      phone = null,
      province = null,
      city = null,
      bio = null,
      profile_image_url = null,
      address_line1 = null,
      address_line2 = null,
      postal_code = null,
      emergency_contact_name = null,
      emergency_contact_phone = null,
      company_name = null,
      company_description = null,
      company_logo_url = null,
      website_url = null,
      years_in_business = null
    } = data

    // Update main user table
    await c.env.DB.prepare(`
      UPDATE users SET
        first_name = ?, last_name = ?, phone = ?, province = ?, city = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(first_name, last_name, phone, province, city, user.user_id).run()

    // Update or insert profile data
    const existingProfile = await c.env.DB.prepare(`
      SELECT id FROM user_profiles WHERE user_id = ?
    `).bind(user.user_id).first()

    if (existingProfile) {
      // Update existing profile
      await c.env.DB.prepare(`
        UPDATE user_profiles SET
          bio = ?, profile_image_url = ?, address_line1 = ?, address_line2 = ?, postal_code = ?,
          emergency_contact_name = ?, emergency_contact_phone = ?,
          company_name = ?, company_description = ?, company_logo_url = ?, website_url = ?, years_in_business = ?,
          updated_at = CURRENT_TIMESTAMP
        WHERE user_id = ?
      `).bind(
        bio, profile_image_url, address_line1, address_line2, postal_code,
        emergency_contact_name, emergency_contact_phone,
        company_name, company_description, company_logo_url, website_url, years_in_business,
        user.user_id
      ).run()
    } else {
      // Insert new profile
      await c.env.DB.prepare(`
        INSERT INTO user_profiles (
          user_id, bio, profile_image_url, address_line1, address_line2, postal_code,
          emergency_contact_name, emergency_contact_phone,
          company_name, company_description, company_logo_url, website_url, years_in_business
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        user.user_id, bio, profile_image_url, address_line1, address_line2, postal_code,
        emergency_contact_name, emergency_contact_phone,
        company_name, company_description, company_logo_url, website_url, years_in_business
      ).run()
    }

    return c.json({ success: true, message: 'Profile updated successfully' })
  } catch (error) {
    console.error('Update profile error:', error)
    return c.json({ error: 'Failed to update profile' }, 500)
  }
})

// Get job categories for service selection
workerRoutes.get('/categories', requireWorkerAuth, async (c) => {
  try {
    const categories = await c.env.DB.prepare(`
      SELECT * FROM job_categories WHERE is_active = 1 ORDER BY name
    `).all()
    
    return c.json({ categories: categories.results || [] })
  } catch (error) {
    console.error('Get categories error:', error)
    return c.json({ error: 'Failed to get categories' }, 500)
  }
})

// ===== SERVICE AREAS MANAGEMENT =====

// Get worker service areas
workerRoutes.get('/service-areas', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const areas = await c.env.DB.prepare(`
      SELECT * FROM worker_service_areas 
      WHERE user_id = ? AND is_active = 1 
      ORDER BY area_name
    `).bind(user.user_id).all()
    
    return c.json({ service_areas: areas.results || [] })
  } catch (error) {
    console.error('Get service areas error:', error)
    return c.json({ error: 'Failed to get service areas' }, 500)
  }
})

// Add service area
workerRoutes.post('/service-areas', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const { area_name } = await c.req.json()

    if (!area_name || area_name.trim().length === 0) {
      return c.json({ error: 'Area name is required' }, 400)
    }

    // Check if area already exists
    const existing = await c.env.DB.prepare(`
      SELECT id FROM worker_service_areas 
      WHERE user_id = ? AND LOWER(area_name) = LOWER(?) AND is_active = 1
    `).bind(user.user_id, area_name.trim()).first()

    if (existing) {
      return c.json({ error: 'Service area already exists' }, 400)
    }

    const result = await c.env.DB.prepare(`
      INSERT INTO worker_service_areas (user_id, area_name)
      VALUES (?, ?)
    `).bind(user.user_id, area_name.trim()).run()

    return c.json({ 
      success: true, 
      message: 'Service area added successfully',
      area_id: result.meta.last_row_id
    })
  } catch (error) {
    console.error('Add service area error:', error)
    return c.json({ error: 'Failed to add service area' }, 500)
  }
})

// Delete service area
workerRoutes.delete('/service-areas/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const areaId = c.req.param('id')

    await c.env.DB.prepare(`
      UPDATE worker_service_areas SET is_active = 0 
      WHERE id = ? AND user_id = ?
    `).bind(areaId, user.user_id).run()

    return c.json({ success: true, message: 'Service area removed successfully' })
  } catch (error) {
    console.error('Delete service area error:', error)
    return c.json({ error: 'Failed to remove service area' }, 500)
  }
})

// ===== HOURS OF OPERATION MANAGEMENT =====

// Get worker hours of operation
workerRoutes.get('/hours', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const hours = await c.env.DB.prepare(`
      SELECT * FROM worker_hours 
      WHERE user_id = ? 
      ORDER BY day_of_week
    `).bind(user.user_id).all()
    
    return c.json({ hours: hours.results || [] })
  } catch (error) {
    console.error('Get hours error:', error)
    return c.json({ error: 'Failed to get hours' }, 500)
  }
})

// Update worker hours of operation
workerRoutes.put('/hours', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const { hours } = await c.req.json()

    if (!Array.isArray(hours) || hours.length !== 7) {
      return c.json({ error: 'Invalid hours data - must be array of 7 days' }, 400)
    }

    // Update each day
    for (let i = 0; i < hours.length; i++) {
      const dayData = hours[i]
      
      await c.env.DB.prepare(`
        INSERT OR REPLACE INTO worker_hours 
        (user_id, day_of_week, is_open, open_time, close_time, updated_at) 
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `).bind(
        user.user_id,
        i, // day_of_week (0=Sunday, 6=Saturday)
        dayData.is_open ? 1 : 0,
        dayData.is_open ? dayData.open_time : null,
        dayData.is_open ? dayData.close_time : null
      ).run()
    }

    return c.json({ success: true, message: 'Hours updated successfully' })
  } catch (error) {
    console.error('Update hours error:', error)
    return c.json({ error: 'Failed to update hours' }, 500)
  }
})

// ===== FILE UPLOAD MANAGEMENT =====

// Upload compliance document
workerRoutes.post('/compliance/upload', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const body = await c.req.parseBody()
    
    const file = body.file as File
    const documentType = body.documentType as string
    
    if (!file || !documentType) {
      return c.json({ error: 'File and document type are required' }, 400)
    }
    
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf']
    if (!allowedTypes.includes(file.type)) {
      return c.json({ error: 'Only JPEG, PNG, and PDF files are allowed' }, 400)
    }
    
    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      return c.json({ error: 'File size must be less than 5MB' }, 400)
    }
    
    // Convert file to base64 for storage (in real app, upload to R2/S3)
    const fileBuffer = await file.arrayBuffer()
    const fileBase64 = btoa(String.fromCharCode(...new Uint8Array(fileBuffer)))
    const fileUrl = `data:${file.type};base64,${fileBase64}`
    
    // Save document record
    const documentId = Math.random().toString(36).substring(2, 15)
    await c.env.DB.prepare(`
      INSERT OR REPLACE INTO compliance_documents (
        id, user_id, document_type, file_name, file_size, file_url, uploaded_at
      ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).bind(documentId, user.user_id, documentType, file.name, file.size, fileUrl).run()
    
    return c.json({ 
      success: true, 
      document: {
        id: documentId,
        document_type: documentType,
        file_name: file.name,
        file_size: file.size,
        file_url: fileUrl
      }
    })
  } catch (error) {
    console.error('Upload compliance document error:', error)
    return c.json({ error: 'Failed to upload document' }, 500)
  }
})

// Get compliance documents
workerRoutes.get('/compliance/documents', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    
    const documents = await c.env.DB.prepare(`
      SELECT id, document_type, file_name, file_size, uploaded_at
      FROM compliance_documents 
      WHERE user_id = ? 
      ORDER BY uploaded_at DESC
    `).bind(user.user_id).all()
    
    return c.json({ documents: documents.results || [] })
  } catch (error) {
    console.error('Get compliance documents error:', error)
    return c.json({ error: 'Failed to get documents' }, 500)
  }
})

// Delete compliance document
workerRoutes.delete('/compliance/documents/:id', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const documentId = c.req.param('id')
    
    await c.env.DB.prepare(`
      DELETE FROM compliance_documents 
      WHERE id = ? AND user_id = ?
    `).bind(documentId, user.user_id).run()
    
    return c.json({ success: true, message: 'Document deleted successfully' })
  } catch (error) {
    console.error('Delete compliance document error:', error)
    return c.json({ error: 'Failed to delete document' }, 500)
  }
})

// Upload profile image
workerRoutes.post('/profile/upload-image', requireWorkerAuth, async (c) => {
  try {
    const user = c.get('user')
    const body = await c.req.parseBody()
    
    const file = body.file as File
    
    if (!file) {
      return c.json({ error: 'File is required' }, 400)
    }
    
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png']
    if (!allowedTypes.includes(file.type)) {
      return c.json({ error: 'Only JPEG and PNG images are allowed' }, 400)
    }
    
    // Check file size (2MB limit for images)
    if (file.size > 2 * 1024 * 1024) {
      return c.json({ error: 'Image size must be less than 2MB' }, 400)
    }
    
    // Convert image to base64 for storage
    const fileBuffer = await file.arrayBuffer()
    const fileBase64 = btoa(String.fromCharCode(...new Uint8Array(fileBuffer)))
    const imageUrl = `data:${file.type};base64,${fileBase64}`
    
    // Update profile with image URL
    await c.env.DB.prepare(`
      UPDATE user_profiles SET
        profile_image_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).bind(imageUrl, user.user_id).run()
    
    return c.json({ 
      success: true, 
      imageUrl: imageUrl,
      message: 'Profile image uploaded successfully'
    })
  } catch (error) {
    console.error('Upload profile image error:', error)
    return c.json({ error: 'Failed to upload image' }, 500)
  }
})

// Update worker compliance information
workerRoutes.put('/compliance', async (c) => {
  // Get session token from Authorization header or cookies
  let sessionToken = c.req.header('Authorization')?.replace('Bearer ', '')
  
  if (!sessionToken) {
    // Try to get from cookies
    const cookieHeader = c.req.header('Cookie')
    if (cookieHeader) {
      const cookies = cookieHeader.split(';')
      for (const cookie of cookies) {
        const trimmedCookie = cookie.trim()
        const equalIndex = trimmedCookie.indexOf('=')
        if (equalIndex !== -1) {
          const name = trimmedCookie.substring(0, equalIndex)
          const value = trimmedCookie.substring(equalIndex + 1)
          if (name === 'session') {
            sessionToken = value
            break
          }
        }
      }
    }
  }
  
  if (!sessionToken) {
    return c.json({ error: 'Authentication required', expired: true }, 401)
  }
  
  try {
    const session = await c.env.DB.prepare(`
      SELECT s.user_id, u.role, u.first_name, u.last_name, u.email, u.is_verified
      FROM user_sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.session_token = ? AND s.expires_at > CURRENT_TIMESTAMP AND u.is_active = 1 AND u.role = 'worker'
    `).bind(sessionToken).first()
    
    if (!session) {
      return c.json({ error: 'Invalid or expired session', expired: true }, 401)
    }
    
    const data = await c.req.json()
    
    // Update or insert worker compliance information
    const complianceExists = await c.env.DB.prepare(`
      SELECT user_id FROM worker_compliance WHERE user_id = ?
    `).bind(session.user_id).first()
    
    if (complianceExists) {
      await c.env.DB.prepare(`
        UPDATE worker_compliance 
        SET wsib_number = ?, wsib_valid_until = ?, 
            insurance_provider = ?, insurance_policy_number = ?, insurance_valid_until = ?,
            license_type = ?, license_number = ?, license_valid_until = ?
        WHERE user_id = ?
      `).bind(
        data.wsibNumber || null,
        data.wsibValidUntil || null,
        data.insuranceProvider || null,
        data.insurancePolicyNumber || null,
        data.insuranceValidUntil || null,
        data.licenseType || null,
        data.licenseNumber || null,
        data.licenseValidUntil || null,
        session.user_id
      ).run()
    } else {
      await c.env.DB.prepare(`
        INSERT INTO worker_compliance (user_id, wsib_number, wsib_valid_until, 
                                     insurance_provider, insurance_policy_number, insurance_valid_until,
                                     license_type, license_number, license_valid_until)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        session.user_id,
        data.wsibNumber || null,
        data.wsibValidUntil || null,
        data.insuranceProvider || null,
        data.insurancePolicyNumber || null,
        data.insuranceValidUntil || null,
        data.licenseType || null,
        data.licenseNumber || null,
        data.licenseValidUntil || null
      ).run()
    }
    
    // Handle document uploads (store as base64 in database for simplicity)
    // In production, you'd want to store these in proper file storage
    if (data.licenseDocument || data.wsibDocument || data.insuranceDocument) {
      // For now, we'll just acknowledge the documents were uploaded
      // In a real system, you'd process and store these files properly
      console.log('Documents uploaded:', {
        license: !!data.licenseDocument,
        wsib: !!data.wsibDocument,
        insurance: !!data.insuranceDocument
      })
    }
    
    return c.json({ message: 'Compliance information updated successfully' })
    
  } catch (error) {
    console.error('Error updating compliance:', error)
    return c.json({ error: 'Failed to update compliance information' }, 500)
  }
})

// Get jobs assigned to current worker (for Kanban board)
workerRoutes.get('/assigned-jobs', requireWorkerAuth, async (c) => {
  try {
    const session = c.get('session')
    
    const jobs = await c.env.DB.prepare(`
      SELECT 
        j.id, j.title, j.description, j.status, j.budget_min, j.budget_max,
        j.location_city, j.location_province, j.urgency, j.created_at, j.actual_completion,
        jc.name as category_name,
        u.first_name as client_first_name, u.last_name as client_last_name,
        (u.first_name || ' ' || u.last_name) as client_name
      FROM jobs j
      LEFT JOIN job_categories jc ON j.category_id = jc.id
      LEFT JOIN users u ON j.client_id = u.id
      WHERE j.assigned_worker_id = ? 
        AND j.status IN ('assigned', 'in_progress', 'completed')
      ORDER BY 
        CASE j.status 
          WHEN 'assigned' THEN 1 
          WHEN 'in_progress' THEN 2 
          WHEN 'completed' THEN 3 
        END,
        j.created_at DESC
    `).bind(session.user_id).all()
    
    // Get milestones for each job
    const jobsWithMilestones = await Promise.all(jobs.results.map(async (job: any) => {
      const milestones = await c.env.DB.prepare(`
        SELECT id, milestone_name, milestone_description, is_completed, completed_at, display_order
        FROM job_milestones
        WHERE job_id = ?
        ORDER BY display_order ASC
      `).bind(job.id).all()
      
      return {
        ...job,
        milestones: milestones.results || []
      }
    }))
    
    return c.json({ 
      success: true, 
      jobs: jobsWithMilestones 
    })
    
  } catch (error) {
    console.error('Error fetching assigned jobs:', error)
    return c.json({ 
      success: false, 
      error: 'Failed to fetch assigned jobs' 
    }, 500)
  }
})

// Update job status (for Kanban drag & drop)
workerRoutes.put('/jobs/:id/status', requireWorkerAuth, async (c) => {
  try {
    const jobId = parseInt(c.req.param('id'))
    const { status } = await c.req.json()
    const session = c.get('session')
    
    // Valid status transitions for workers
    const validStatuses = ['assigned', 'in_progress', 'completed']
    if (!validStatuses.includes(status)) {
      return c.json({ error: 'Invalid status' }, 400)
    }
    
    // Verify the job is assigned to this worker
    const job = await c.env.DB.prepare(`
      SELECT id, status as current_status, assigned_worker_id, title
      FROM jobs 
      WHERE id = ? AND assigned_worker_id = ?
    `).bind(jobId, session.user_id).first()
    
    if (!job) {
      return c.json({ error: 'Job not found or not assigned to you' }, 404)
    }
    
    // Prevent invalid status transitions
    const currentStatus = job.current_status
    if (currentStatus === 'completed' && status !== 'completed') {
      return c.json({ error: 'Cannot change status of completed job' }, 400)
    }
    
    // Update job status
    await c.env.DB.prepare(`
      UPDATE jobs 
      SET status = ?, 
          updated_at = CURRENT_TIMESTAMP,
          actual_completion = CASE WHEN ? = 'completed' THEN CURRENT_TIMESTAMP ELSE actual_completion END
      WHERE id = ?
    `).bind(status, status, jobId).run()
    
    // Log status change
    await c.env.DB.prepare(`
      INSERT INTO job_status_logs (job_id, old_status, new_status, changed_by, change_reason)
      VALUES (?, ?, ?, ?, ?)
    `).bind(jobId, currentStatus, status, session.user_id, `Status updated via Kanban board`).run()
    
    // Update milestones based on new status
    if (status === 'in_progress') {
      // Mark "Work Started" milestone as completed
      await c.env.DB.prepare(`
        UPDATE job_milestones 
        SET is_completed = TRUE, completed_at = CURRENT_TIMESTAMP, completed_by = ?
        WHERE job_id = ? AND milestone_name = 'Work Started'
      `).bind(session.user_id, jobId).run()
      
      // Create "Work Started" milestone if it doesn't exist
      await c.env.DB.prepare(`
        INSERT OR IGNORE INTO job_milestones (job_id, milestone_name, milestone_description, is_completed, completed_at, completed_by, display_order)
        VALUES (?, 'Work Started', 'Worker has started working on the job', TRUE, CURRENT_TIMESTAMP, ?, 2)
      `).bind(jobId, session.user_id).run()
    } else if (status === 'completed') {
      // Mark "Work Completed" milestone as completed
      await c.env.DB.prepare(`
        UPDATE job_milestones 
        SET is_completed = TRUE, completed_at = CURRENT_TIMESTAMP, completed_by = ?
        WHERE job_id = ? AND milestone_name = 'Work Completed'
      `).bind(session.user_id, jobId).run()
      
      // Create "Work Completed" milestone if it doesn't exist
      await c.env.DB.prepare(`
        INSERT OR IGNORE INTO job_milestones (job_id, milestone_name, milestone_description, is_completed, completed_at, completed_by, display_order)
        VALUES (?, 'Work Completed', 'All work has been completed', TRUE, CURRENT_TIMESTAMP, ?, 3)
      `).bind(jobId, session.user_id).run()
    }
    
    return c.json({ 
      success: true, 
      message: `Job status updated to ${status}`,
      job_id: jobId,
      new_status: status
    })
    
  } catch (error) {
    console.error('Error updating job status:', error)
    return c.json({ 
      success: false, 
      error: 'Failed to update job status' 
    }, 500)
  }
})